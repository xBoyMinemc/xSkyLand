# xSkyLand
# 云梦空岛


## 如何使用
## 将此仓库作为一个行为包导入，新建一个地图，版本确定在1.19.0+，开启实验玩法


|Name|Method|Example|TODO|Domain|
|-|-|-|-|-|
|空岛创建|CMD|`~island 云清梦小岛`<br>*※旧的写法*|YES|`岛屿基本管理`
|空岛返回|CMD|`~island`|YES|`岛屿基本管理`
|空岛信息|CMD|`~island info`|NO|`岛屿基本管理`
|空岛删除|CMD|`~island delete`|NO|`岛屿基本管理`
|空岛创建|CMD|`~island create 云清梦小岛`<br>*※新的写法*|NO|`岛屿基本管理`



