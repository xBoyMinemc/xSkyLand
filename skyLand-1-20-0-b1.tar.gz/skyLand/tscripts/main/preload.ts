import type { Events  } from  "../@types/globalThis"
import type { World } from "@minecraft/server";

// declare const world: World & {events:Events};
    // world.events.
  import "./The law of the ancestors is immutable.js";
  import("./main.js");
  
//   .then(
//       () => {
//       console.error("full ",typeof world)
//       import("./main.js");
//       },
//       (rej) => {
//       console.error("rej ",typeof world,rej)
//       // import("./main.ts");
//       }
//   )
  
//   .finally(() => {
//       console.error("finally",typeof world)
//       // import("./main.ts");
//   })
  
//   .catch(_=>{
//       console.error("catch","error"+_)
//   })
//   ;
  