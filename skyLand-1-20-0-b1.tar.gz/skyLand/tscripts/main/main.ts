
// import { world } from "@minecraft/server";
import "../xBoyIsLand/MangeIsLand/main.js";
import "../xBoyIsLand/DefendIsLand/main";
// import "../test/test";

