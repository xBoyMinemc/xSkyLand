const config = {
    HoldRadius : 3,//主城空置半径
}
export default config;