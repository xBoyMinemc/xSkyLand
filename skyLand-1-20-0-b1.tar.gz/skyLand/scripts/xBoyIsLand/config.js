const config = {
    HoldRadius: 3,
};
export default config;
