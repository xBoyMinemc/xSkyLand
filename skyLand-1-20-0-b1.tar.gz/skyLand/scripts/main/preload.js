import "./The law of the ancestors is immutable.js";
import("./main.js");
