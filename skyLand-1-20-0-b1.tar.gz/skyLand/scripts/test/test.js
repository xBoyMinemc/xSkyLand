import x from "../server-plus/index";
x(world);
world.events.beforePlayerSleep.subscribe((event) => event.player.runCommandAsync("me zzz 睡大觉"));
